## Plots from simulations

BM4<-read.csv("BM1BM2.out.p4.csv",header=T,row.names=1)
BM8<-read.csv("BM1BM2.out.csv",header=T,row.names=1)

OU4<-read.csv("BMOU.out.N32.p4.csv",header=T,row.names=1)
OU8<-read.csv("BMOU.out.N32.p8.csv",header=T,row.names=1)
OU12<-read.csv("BMOU.out.N32.p12.csv",header=T,row.names=1)

resBM4<-mean(ifelse(BM4<=0.05,1,0))
resBM8<-mean(ifelse(BM8<=0.05,1,0))

resOU4<-mean(ifelse(OU4<= -4,1,0))
resOU8<-mean(ifelse(OU8<= -4,1,0))
resOU12<-mean(ifelse(OU12<= -4,1,0))


p<-rbind(c(resBM4,resOU4),c(resBM8,resOU8),c(0,resOU12))


barplot(p,beside=T,ylim=c(0,1),
        xlab="Model Comparison",ylab="% Misspecification")
