#Degree of misspecification from mvMorph

####
library(geiger)
library(phytools)
library(mvMORPH)

R<-c(0)
p<-8
Nspec=32
iter=100

tree<-lapply(1:iter, function(j) compute.brlen(rtree(Nspec)))
tree<-lapply(1:iter, function(j) {gp<-gl(2,Nspec/2); names(gp)<-tree[[j]]$tip.label
  make.simmap(tree[[j]],gp, model="ER", nsim=1)
})
s=matrix(R,ncol=p,nrow=p); diag(s)<-1
y<-lapply(1:iter, function(j) sim.char(tree[[j]],s,iter)[,,1])
BM1.res<-lapply(1:iter, function(j)  mvBM(tree[[j]],y[[j]],model="BM1",method="pic", echo=F,diagnostic=F))
BMM.res<-lapply(1:iter, function(j)  mvBM(tree[[j]],y[[j]],model="BMM", echo=F,diagnostic=F))
BM.p<-unlist(lapply(1:iter, function(j) LRT(BMM.res[[j]],BM1.res[[j]],echo=F)$pval ))
    
mean(ifelse(BM.p<=0.05,1,0))

write.csv(BM.p,"BM1BM2.out.csv")