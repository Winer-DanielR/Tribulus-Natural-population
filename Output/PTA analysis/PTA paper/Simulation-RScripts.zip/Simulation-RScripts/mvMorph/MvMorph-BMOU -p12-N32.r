#Degree of misspecification from mvMorph
    #NOTE: mvMorph crashes a lot! 
       #placed in loop so it may be restarted at point of crash
####
library(geiger)
library(phytools)
library(mvMORPH)

R<-c(0)
p<-12
Nspec=32
iter=100
BM.p<-array(NA,dim=(c(iter)))
for (j in 1:iter){
    tree<-compute.brlen(rtree(Nspec))  #random splits tree
    s=matrix(R,ncol=p,nrow=p); diag(s)<-1
    y<-sim.char(tree,s,1)[,,1] 
    BM1.res<-mvBM(tree,y,model="BM1",method="pic", echo=F,diagnostic=F)
    OU.res<-mvOU(tree,y,model="OU1", method="inverse",echo=F,diagnostic=F)

    BM.p[j]<-OU.res$AIC-BM1.res$AIC #compare AIC
    print(j)
  }


#AIC comparison @ 4+
length(which(BM.p< -4))

write.csv(BM.p,"BMOU.out.N32.p12.csv")
