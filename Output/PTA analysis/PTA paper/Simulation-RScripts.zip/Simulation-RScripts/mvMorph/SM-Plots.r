## Plots for Supp. Material mvMORPH and mvSLOUCH
  #Summary values obtained from csv files

mvmorph.p<-c(15,25,47)
mvmorph.n<-c(15,13,13)
mvslouch.p<-c(42,01,01)
mvslouch.n<-c(42,90,86)

barplot(mvmorph.p,ylim=c(0,100),col=c("black","darkgray","lightgray"),space=0,ylab="% Misspecification")
barplot(mvmorph.n,ylim=c(0,100),col=c("black","darkgray","lightgray"),space=0,ylab="% Misspecification")
barplot(mvslouch.p,ylim=c(0,100),col=c("black","darkgray","lightgray"),space=0,ylab="% Misspecification")
barplot(mvslouch.n,ylim=c(0,100),col=c("black","darkgray","lightgray"),space=0,ylab="% Misspecification")




