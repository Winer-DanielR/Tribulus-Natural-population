#Simple data example for Fig 1, with full logL and axis-summary logL

####
library(ape)
library(phytools)
library(geiger)
library(phylocurve)
library(mvtnorm)
library(scatterplot3d)
source('phylomorphospace3d2.r')

##Fig 1A/B
N=30
p=3
gp<-gl(2,15)
s<-matrix(.7,nrow=p, ncol=p); diag(s)<-1
set.seed(12)
y1<-rmvnorm(N/2,sigma=s,mean=c(0,0,0))
set.seed(12)
y2<-rmvnorm(N/2,sigma=s,mean=c(0,0,.5))
y<-rbind(y1,y2)

summary(manova(y~gp))
summary(manova(prcomp(y)$x~gp))

color<-c(rep("black",N/2),rep("gray",N/2))
scatterplot3d(y,color=color,pch=20,asp=1,cex.symbols=2)
scatterplot3d(prcomp(y)$x,color=color,pch=20,asp=1,cex.symbols=2)

##Fig 1C/D
N=16
p=3
s<-matrix(.7,nrow=p, ncol=p); diag(s)<-1
set.seed(12)  #for repeatability of data
tree<-compute.brlen(rtree(N)) 
set.seed(12)  #for repeatability of data  #was seed=2 with
y<-sim.char(tree,s,1)[,,1]

phylomorphospace3d2(tree,y,method="static",control=list(ftype="off"))
phylomorphospace3d2(tree,prcomp(y)$x,method="static")


#### comparisons
#Revell & Harmon 2008 logL for multivariate data
StandardLogL<-function(phy,x){
  x<-as.matrix(x)
  N<-nrow(x)
  p<-ncol(x)
  C<-vcv.phylo(phy)
  C<-C[rownames(x),rownames(x)]
  a<-colSums(solve(C))%*%x/sum(solve(C))   
  D<-matrix(0,N*p,p)
  for(i in 1:(N*p)) for(j in 1:p) if((j-1)*N<i&&i<=j*N) D[i,j]=1.0
  y<-as.matrix(as.vector(x))
  one<-matrix(1,N,1)
  R<-t(x-one%*%a)%*%solve(C)%*%(x-one%*%a)/N
  L1<- -(t(y-D%*%t(a))%*%solve(kronecker(R,C))%*%(y-D%*%t(a))/2)-N*p*log(2*pi)/2-determinant(kronecker
                                                                                             (R,C))$modulus[1]/2
  return(L1)
}

StandardLogL(tree,y)
StandardLogL(tree,prcomp(y)$x)

#logL from sumPCaxes
sum(apply(prcomp(y)$x, 2, function(x) StandardLogL(tree,x))) # not the same

sum(apply(phyl.pca(tree,y)$S, 2, function(x) StandardLogL(tree,x))) # same as full logL, but only under BM

#PCL: not the same as full logL, and not the same with orientation
evo.model(tree,y,method="Pairwise ML")
evo.model(tree,prcomp(y)$x,method="Pairwise ML")



