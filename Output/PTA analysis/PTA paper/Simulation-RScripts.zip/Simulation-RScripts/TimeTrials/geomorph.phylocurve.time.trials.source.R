

comp.times <- function(type, trees, tree.data, tree.data2 = NULL, 
                       gp.data = NULL, iter=999, times = 3, save.name = "comp.times"){
  
  save.name <- paste(save.name, "Rdata", sep=".")
  phylocurve.times <- geomorph.times <- 
    as.list(array(NA,length(trees))) # Map does not work with phylocurve functions
  
  # Simulation runs
  if(type == "procD.pgls"){
    for(i in 1:length(trees)){
      phy <- trees[[i]]
      phy.data <- tree.data[[i]]
      phy.data2 <- tree.data2[[i]]
      resP <- resG <- array(NA, length(phy.data))
      for(ii in 1:length(phy.data)){
        Y <- phy.data[[ii]]
        X <- phy.data2[[ii]]
        assign("X", X, envir=globalenv())
        assign("Y", Y, envir=globalenv())
        gdf <- geomorph.data.frame(Y=Y, X=X)
        timer <- microbenchmark(
          fast.geomorph.procD.pgls(Y~X, phy=phy, iter=iter, verbose = FALSE),
          procD.pgls(Y~X, phy=phy, iter=iter, data=gdf, print.progress = FALSE, RRPP=F),
          times = times)
        res<- as.vector(by(timer$time, timer$expr, mean))
        resP[[ii]] <- res[1]
        resG[[ii]] <- res[2]
      }
      phylocurve.times[[i]] <- resP
      geomorph.times[[i]] <- resG
      
    }
  }
  
  if(type == "compare.evol.rates"){
    for(i in 1:length(trees)){
      phy <- trees[[i]]
      phy.data <- tree.data[[i]]
      gp <- gp.data[[i]]
      resP <- resG <- array(NA, length(phy.data))
      for(ii in 1:length(phy.data)){
        Y <- phy.data[[ii]]
        timer <- microbenchmark(
          fast.geomorph.compare.evol.rates(phy=phy, A=Y, gp=gp, iter=iter, ShowPlot = FALSE),
          compare.evol.rates(A=Y, phy=phy, gp=gp, iter=iter, print.progress = FALSE),
          times = times)
        res<- as.vector(by(timer$time, timer$expr, mean))
        resP[[ii]] <- res[1]
        resG[[ii]] <- res[2]
      }
      phylocurve.times[[i]] <- resP
      geomorph.times[[i]] <- resG
      save(phylocurve.times, geomorph.times, file = save.name)
    }
  }  

  if(type == "compare.multi.evol.rates"){
    for(i in 1:length(trees)){
    phy <- trees[[i]]
    phy.data <- tree.data[[i]]
    resP <- resG <- array(NA, length(phy.data))
    for(ii in 1:length(phy.data)){
      gp <- gp.data[[ii]]
      Y <- phy.data[[ii]]
      timer <- microbenchmark(
        fast.geomorph.compare.multi.evol.rates(phy=phy, A=Y, gp=gp, 
           Subset = TRUE, iter=iter, ShowPlot = FALSE),
        compare.multi.evol.rates(A=Y, phy=phy, gp=gp, 
           Subset = TRUE, iter=iter, print.progress = FALSE),
        times = times)
      res<- as.vector(by(timer$time, timer$expr, mean))
      resP[[ii]] <- res[1]
      resG[[ii]] <- res[2]
      }
      phylocurve.times[[i]] <- resP
      geomorph.times[[i]] <- resG
      save(phylocurve.times, geomorph.times, file = save.name)
    }
  }
        
  if(type == "physignal"){
    for(i in 1:length(trees)){
      phy <- trees[[i]]
      phy.data <- tree.data[[i]]
      resP <- resG <- array(NA, length(phy.data))
      for(ii in 1:length(phy.data)){
        Y <- phy.data[[ii]]
        timer <- microbenchmark(
          fast.geomorph.physignal(phy=phy, A=Y, iter=iter, 
                                  method = "Kmult", ShowPlot = FALSE),
          physignal(A=Y, phy=phy, iter=iter, print.progress = FALSE),
          times = times)
        res<- as.vector(by(timer$time, timer$expr, mean))
        resP[[ii]] <- res[1]
        resG[[ii]] <- res[2]
      }
      phylocurve.times[[i]] <- resP
      geomorph.times[[i]] <- resG
      save(phylocurve.times, geomorph.times, file = save.name)
    }
  }
  
  if(type == "phylo.integration"){
    for(i in 1:length(trees)){
      phy <- trees[[i]]
      phy.data <- tree.data[[i]]
      phy.data2 <- tree.data2[[i]]
      resP <- resG <- array(NA, length(phy.data))
      for(ii in 1:length(phy.data)){
        Y <- phy.data[[ii]]
        X <- phy.data2[[ii]]
        timer <- microbenchmark(
          fast.geomorph.phylo.integration(A=Y, A2=X, phy=phy, iter=iter, ShowPlot = FALSE),
          phylo.integration(A=Y, A2=X, phy=phy, iter=iter, print.progress = FALSE),
          times = times)
        res<- as.vector(by(timer$time, timer$expr, mean))
        resP[[ii]] <- res[1]
        resG[[ii]] <- res[2]
      }
      phylocurve.times[[i]] <- resP
      geomorph.times[[i]] <- resG
      save(phylocurve.times, geomorph.times, file = save.name)
    }
  }
  
  GT.summary <- simplify2array(geomorph.times)
  PT.summary <- simplify2array(phylocurve.times)
  
  rownames(GT.summary) <- rownames(PT.summary) <- 
    paste(ntraits, "traits", sep=".")
  colnames(GT.summary) <- colnames(PT.summary) <- 
    paste(nspecies, "species", sep=".")
  
  time.dif <- (GT.summary - PT.summary)/10^9 # convert to seconds
  
  save(phylocurve.times, geomorph.times, PT.summary, GT.summary,
       time.dif, file = save.name)
  
  out <- list(phylocurve.times=phylocurve.times, 
              geomorph.times=geomorph.times, 
              PT.summary=PT.summary, 
              GT.summary=GT.summary,
              time.dif=time.dif, type=type)
  
  class(out) <- "comp.times"
  out
}

print.comp.times <- function(x,...) {
  cat("\n\n")
  cat(paste(x$type,": geomorph - phylocurve, seconds", sep=""))
  cat("\n\n")
  print(x$time.dif)
  cat("\n\n")
  invisible(x)
}

sumamry.comp.times <- function(object, ...){
  print.comp.times(object, ...)
}
  