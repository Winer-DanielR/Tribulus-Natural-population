#------------------------------------------------------------------------------------------
#                                                                                          |
# Comparisons between geomorph (currently 3.0.3) and phylocurve 2.0.6 comparable functions |
#                                                                                          |
#------------------------------------------------------------------------------------------

# General Set-up

library(geomorph)
library(phylocurve)
library(geiger)
library(microbenchmark)

source("geomorph.phylocurve.time.trials.source.R")


# Species and traits

nspecies <- c(10, 24, 50, 100, 250, 500) # Goolsby (2016) also used 1,000 species
ntraits <- c(10, 24, 50, 100, 250, 500) 

# Defining trees for simulations

trees <- lapply(1:length(nspecies), function(j){
  nsp <- nspecies[j]
  rtree(n=nsp)
})

# Function to apply traits to trees

apply.traits <- function(x, ntraits){
  lapply(1:length(ntraits), function(j){
    p <- ntraits[j]
    B <- diag(1,p)
    sim.char(x,par=B)[,,1]
  })
}

# Data (mapped on trees)

tree.data <- lapply(trees, apply.traits, ntraits)

# Analysis iterations and no. computation times

iter <- 4
times <- 1

# procD.pgls -------------------------------------------------------------------------------

# Make independent variable

xtraits <- c(1,1,1,1,1,1)
tree.data2 <- lapply(trees, apply.traits, xtraits)

comp.times(type = "procD.pgls", trees, tree.data, tree.data2 = tree.data2, 
           gp.data = NULL, iter=iter, times = times, save.name = "procD.pgls.comp")

# Note #------------------------------------------------------------------------------------

# geomorph and phylocurve procD.pgls functions produce different SS; they are only the same
# for simple phylogenetic regression.  The phylocurve 2.0.6 version does not calculate SS
# appropriately.  An example is shown below with univariate data, so that parametric ANOVA
# can also be run.

phy <- trees[[3]]
Y <- tree.data[[3]][[1]][,1] # univariate data
x1 <- sim.char(phy, par=1)
x2 <- sim.char(phy, par=1)
x3 <- sim.char(phy, par=1)

procD.pgls(Y ~ x1 + x2 + x3, phy = phy)
fast.geomorph.procD.pgls(Y ~ x1 + x2 + x3, phy = phy)

# Which is correct?

Pcor <- procD.pgls(Y ~ x1 + x2 + x3, phy = phy)$Pcor # Phylogenetic correction matrix
Int <- rep(1,length(Y)) # The intercept must also be transformed
anova(lm(Pcor%*%Y ~ Pcor%*%Int + Pcor%*%x1 + Pcor%*%x2 + Pcor%*%x3 + 0))

# geomorph produces appropriate SS; phylocurve does not
# geomorph produces sampling distributions similar to F distributions (P-values
# are about the same as parametric values); phylocurve cannot be accurate due
# to removal of the observed value and recursive updates.


# compare.evol.rate ----------------------------------------------------------------------

# simulate group data

gp.data <- lapply(1:length(trees), function(j){ # binary factors
  phy <- trees[[j]]
  n <- length(phy$tip.label)
  g <- as.factor(round(runif(n)))
  names(g) <- phy$tip.label
  g
})

comp.times(type = "compare.evol.rates", trees, tree.data, tree.data2 = NULL, 
           gp.data = gp.data, iter=iter, times = times, 
           save.name = "compare.evol.rates.comp")


# compare.multi.evol.rates ----------------------------------------------------------------

# Simulate partition data

gp.data <- lapply(1:length(ntraits), function(j){ # binary factors
  p <- ntraits[j]
  as.factor(round(runif(p)))
})

comp.times(type = "compare.multi.evol.rates", trees, tree.data, tree.data2 = NULL, 
           gp.data = gp.data, iter=iter, times = times, 
           save.name = "compare.multi.evol.rates.comp")

# physignal ------------------------------------------------------------------------------

comp.times(type = "physignal", trees, tree.data, tree.data2 = NULL, 
           gp.data = NULL, iter=iter, times = times, 
           save.name = "physignal.comp")

# phylo.integration -------------------------------------------------------------------------

# Note: fast.geomorph.phylo.integration can crash (fortran) with high-dimensional
# data if traits >> species.  Thus, the simulation runs might have to be censored.

# ntraits <- c(10, 24, 50) # e.g., if censored

tree.data2 <- lapply(trees, apply.traits, ntraits)

comp.times(type = "phylo.integration", trees, tree.data, tree.data2 = tree.data2, 
           gp.data = NULL, iter=iter, times = times, 
           save.name = "phylo.integration.comp")
