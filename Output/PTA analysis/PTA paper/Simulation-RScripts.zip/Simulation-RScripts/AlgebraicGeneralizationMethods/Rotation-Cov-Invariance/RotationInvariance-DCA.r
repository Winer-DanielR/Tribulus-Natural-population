#Demonstration that PCM algabraic generalizations of Adams are rotation-invariant

####
library(geomorph)
library(geiger)
source('compare.evol.rates.p.r')

R<-c(0,0.5,0.9)
p<-8
Nspec=32
iter<-100

physig1<-physig2<-rate1<-rate2<-rate1.p<-rate2.p<-pgls1<-pgls2<-
  ppls1<-ppls2<-array(NA,dim=(c(iter,2*length(R))))
for(i in 1:length(R)){
    s=matrix(R[i],ncol=p,nrow=p); diag(s)<-1
    #tree<-lapply(1:iter, function(j) pbtree(n=Nspec,scale=1)) #PB tree
    tree<-lapply(1:iter, function(j) compute.brlen(rtree(Nspec))) #random splits tree
    y<-lapply(1:iter, function(j) sim.char(tree[[j]],s,iter)[,,1])
    x<-lapply(1:iter, function(j) sim.char(tree[[j]],1,iter)[,,1])
    x.multi<-lapply(1:iter, function(j) sim.char(tree[[j]],s,iter)[,,1])
    groups<-lapply(1:iter, function(j) gl(2,Nspec/2))
    for(j in 1:iter){names(groups[[j]])<-tree[[j]]$tip.label}
    gdf<-lapply(1:iter, function(j) geomorph.data.frame(y=y[[j]],x=x[[j]],x.multi=x.multi[[j]],
          groups=groups[[j]],tree=tree[[j]]  )   )
    
    res<-lapply(1:iter, function(j) physignal(y[[j]],tree[[j]],print.progress = FALSE) )    
      physig1[,i]<-unlist(lapply(1:iter, function(j) res[[j]]$phy.signal) )
      physig1[,(i+length(R))]<-unlist(lapply(1:iter, function(j) res[[j]]$pvalue) )

    res<-lapply(1:iter, function(j) physignal(prcomp(y[[j]])$x,tree[[j]],print.progress = FALSE) )    
      physig2[,i]<-unlist(lapply(1:iter, function(j) res[[j]]$phy.signal) )
      physig2[,(i+length(R))]<-unlist(lapply(1:iter, function(j) res[[j]]$pvalue) )
      
    res<-lapply(1:iter, function(j) compare.evol.rates(y[[j]],tree[[j]],gp=groups[[j]],print.progress = FALSE) )    
      rate1[,i]<-unlist(lapply(1:iter, function(j) res[[j]]$sigma.d.ratio) )
      rate1[,(i+length(R))]<-unlist(lapply(1:iter, function(j) res[[j]]$P.value) )
      
    res<-lapply(1:iter, function(j) compare.evol.rates(prcomp(y[[j]])$x,tree[[j]],gp=groups[[j]],print.progress = FALSE) )    
      rate2[,i]<-unlist(lapply(1:iter, function(j) res[[j]]$sigma.d.ratio) )
      rate2[,(i+length(R))]<-unlist(lapply(1:iter, function(j) res[[j]]$P.value) )
      
    res<-lapply(1:iter, function(j) compare.evol.rates.p(y[[j]],tree[[j]],gp=groups[[j]],print.progress = FALSE) )    
      rate1.p[,i]<-unlist(lapply(1:iter, function(j) res[[j]]$sigma.d.ratio) )
      rate1.p[,(i+length(R))]<-unlist(lapply(1:iter, function(j) res[[j]]$P.value) )
      
    res<-lapply(1:iter, function(j) compare.evol.rates.p(prcomp(y[[j]])$x,tree[[j]],gp=groups[[j]],print.progress = FALSE) )    
      rate2.p[,i]<-unlist(lapply(1:iter, function(j) res[[j]]$sigma.d.ratio) )
      rate2.p[,(i+length(R))]<-unlist(lapply(1:iter, function(j) res[[j]]$P.value) )
      
    res<-lapply(1:iter, function(j) procD.pgls(y~x,tree,data=gdf[[j]],print.progress = FALSE) )    
      pgls1[,i]<-unlist(lapply(1:iter, function(j) res[[j]]$aov.table[1,2]) )
      pgls1[,(i+length(R))]<-unlist(lapply(1:iter, function(j) res[[j]]$aov.table[1,7]) )      

    res<-lapply(1:iter, function(j) procD.pgls(prcomp(y)$x~x,tree,data=gdf[[j]],print.progress = FALSE) )    
      pgls2[,i]<-unlist(lapply(1:iter, function(j) res[[j]]$aov.table[1,2]) )
      pgls2[,(i+length(R))]<-unlist(lapply(1:iter, function(j) res[[j]]$aov.table[1,7]) ) 

    res<-lapply(1:iter, function(j) phylo.integration(y[[j]],x.multi[[j]],tree[[j]],print.progress = FALSE) )    
      ppls1[,i]<-unlist(lapply(1:iter, function(j) res[[j]]$r.pls) )
      ppls1[,(i+length(R))]<-unlist(lapply(1:iter, function(j) res[[j]]$P.value) )      
      
    res<-lapply(1:iter, function(j) phylo.integration(prcomp(y[[j]])$x,x.multi[[j]],tree[[j]],print.progress = FALSE) )    
      ppls2[,i]<-unlist(lapply(1:iter, function(j) res[[j]]$r.pls) )
      ppls2[,(i+length(R))]<-unlist(lapply(1:iter, function(j) res[[j]]$P.value) ) 
      
}

diag(cor(physig1,physig2)) #p-values identical, so r=1
diag(cor(rate1,rate2))
diag(cor(rate1.p,rate2.p))
diag(cor(pgls1,pgls2))
diag(cor(ppls1,ppls2))


write.csv(physig1,"physig1.csv")
write.csv(physig2,"physig2.csv")
write.csv(rate1,"rate1.csv")
write.csv(rate2,"rate2.csv")
write.csv(rate1.p,"rate1.p.csv")
write.csv(rate2.p,"rate2.p.csv")
write.csv(pgls1,"pgls1.csv")
write.csv(pgls2,"pgls2.csv")
write.csv(ppls1,"ppls1.csv")
write.csv(ppls2,"ppls2.csv")


