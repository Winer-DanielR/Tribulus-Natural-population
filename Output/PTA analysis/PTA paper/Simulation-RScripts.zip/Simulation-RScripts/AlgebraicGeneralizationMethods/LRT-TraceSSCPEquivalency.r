# example that LRT and tr(SSCP) do equivalent things for testing hypotheses.

Result <- NULL
iter = 1000
n <- 100
y <- rnorm(n)
x <- rnorm(n)
fitn <- lm(y~1)
fitf <- lm(y~x)
logLik(fitn)
logLik(fitf)
2*(logLik(fitf)-logLik(fitn))

LRT <- function(x, y){
  fitn <- lm(y~1)
  fitf <- lm(y~x)
  2*(logLik(fitf)-logLik(fitn))
}
LRT(x,y)

LRT.t <- function(x, y){ # LRT based on trace
  fitn <- lm(y~1)
  fitf <- lm(y~x)
  2*(var(fitf$fitted.values)-var(fitn$fitted.values))
}

SSdif <- function(x, y){ # LRT based on trace
  fitn <- lm(y~1)
  fitf <- lm(y~x)
  sum((fitf$fitted.values-fitn$fitted.values)^2)
}

for(i in 1:iter) {
  y <- rnorm(n)
  x <- rnorm(n)
  Result <- rbind(Result, c(LRT=LRT(x,y), 
                            LRT.t=LRT.t(x,y),
                            SS=SSdif(x,y)))
}

ResultR <- apply(Result, 2, rank)

pairs(Result)
pairs(ResultR)
cor(Result)
cor(ResultR)

plot(ResultR[,1],ResultR[,3],pch=21, bg="black", xaxt='n', yaxt='n')
