#Evaluate sigmaDperm approach

####
library(geomorph)
library(geiger)
library(phylocurve)
source('compare.evol.rates.p.r')

R<- 0 #c(0,0.5,0.9)  
p<- c(2,8,16,32)
sig2<-c(1.0,2.0,4.0)
Nspec=32
iter<-1000


#type I error & power: RUN SEPARATELY FOR EACH Y-cov
rate1<-rate2<-array(NA,dim=(c(iter,length(p),length(sig2))))
for (i in 1:length(R)){
  for (j in 1:length(p)){
    for (k in 1:length(sig2)){
      for (m in 1:iter){
        tree<-compute.brlen(rtree(Nspec))  #random splits tree 
        s1=matrix(R[i],ncol=p[j],nrow=p[j]); diag(s1)<-1
        s2=matrix(R[i],ncol=p[j],nrow=p[j]); diag(s2)<-sig2[k]
        s<-list(s1,s2)        
        gp <-gl(2,Nspec/2); names(gp)<-tree$tip.label
        pe <- paint.edges(tree=tree,species.groups=gp)
        y <- phylocurve:::sim.groups(tree=tree,groups=gp,painted.edges=pe,phylocov=s,nsim=1)$trait_data[[1]]

        rate1[m,j,k]<-compare.evol.rates.p(y,tree,gp=gp,print.progress = FALSE)$P.value
        rate2[m,j,k]<-compare.evol.rates.p(prcomp(y)$x,tree,gp=gp,print.progress = FALSE)$P.value
        print(c(m,j,k))
      }
    }
    
  }
}


#3D array summary 
res1<-res2<-NULL
for (i in 1:length(sig2)){
  res1<-rbind(res1,apply(ifelse(rate1[,,i]<=0.05,1,0),2,mean))
  res2<-rbind(res2,apply(ifelse(rate2[,,i]<=0.05,1,0),2,mean)  )
}
row.names(res1)<-row.names(res2)<-sig2
colnames(res1)<-colnames(res2)<-p

res1
res2
