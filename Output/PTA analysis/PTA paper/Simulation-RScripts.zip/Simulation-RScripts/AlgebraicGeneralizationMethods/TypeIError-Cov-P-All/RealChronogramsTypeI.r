# Evaluate condition number of actual chronograms. Compare to theoretical
  #for all trees with 32-512 species

####
library(ape)
library(geiger)
library(geomorph)

load("opentree_chronograms.rda")
ntrees<-length(datelife.cache$trees)
ntaxa<-unlist(lapply(1:ntrees, function(x) length(datelife.cache$trees[[x]]$tip.label    )))

#Prune out large trees (N > 512), small trees (N<32) and those with negative branch lengths  
large<-which(ntaxa >512)
small<-which(ntaxa<32)
bad<-130 #see orig paper
good.branch<-array(NA,length(ntaxa))
for (j in 1:length(ntaxa)){
  good.branch[j]<-any(datelife.cache$trees[[j]]$edge.length<0)
}
totgp<-seq(1,length(ntaxa)); totgp<-totgp[-c(small,large,which(good.branch==TRUE),bad)]

trees<-datelife.cache$trees; trees<-trees[totgp] # 104 phylogenies
Ntaxa<-unlist(lapply(1:length(trees), function(x) length(trees[[x]]$tip.label)  )  )
#NOTE: some trees have duplicate tip names. Rename everything
for (i in 1:length(trees)){
  trees[[i]]$tip.label<-seq(1:Ntaxa[i])
}

#type I error simulations
Ntraits<-c(2,4,8,16,32)
Nsimul<-1000

PGLS.p<-array(NA,dim=c(length(Ntaxa),length(Ntraits)))
for (j in 1:length(Ntaxa)){
  for (i in 1:length(Ntraits)){
    s<-diag(1,Ntraits[i])
    sim.dat<-sim.char(trees[[j]],s,Nsimul) 
    x<-1
    res<-unlist(lapply(1:Nsimul, function(x)  procD.pgls(sim.dat[,-1,x]~sim.dat[,1,x],trees[[j]],print.progress=F)$aov.table[1,7]  )  )
    PGLS.p[j,i]<-mean(ifelse(res<=0.05,1,0)) 
  }  #close i (Ntraits)
} #close j (trees)

PGLS.p

apply(PGLS.p,2,mean)



