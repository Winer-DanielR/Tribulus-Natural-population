#Relationship of Condition Number and significance for PB trees used in PGLS

####
library(geomorph)
library(geiger)
library(phytools)

#3: PGLS
Nspec<-32
p<-32
iter<-1000
pgls.p<-array(NA,dim=(c(iter,2)))

tree<-lapply(1:iter, function(j) pbtree(n=Nspec,scale=1))
s=diag(ncol=(p+1),nrow=(p+1)) 
dat<-lapply(1:iter, function(j) sim.char(tree[[j]],s,1)[,,1] )
y<-lapply(1:iter, function(j) dat[[j]][,1:p])
x<-lapply(1:iter, function(j) dat[[j]][,p+1])
gdf<-lapply(1:iter, function(j) geomorph.data.frame(y=y[[j]],x=x[[j]],tree=tree[[j]]  )   )

pgls.p[,1]<-unlist(lapply(1:iter, function(j) procD.pgls(y~x,tree,data=gdf[[j]],print.progress = FALSE)$aov.table[1,7] ) )  
pgls.p[,2]<-unlist(lapply(1:iter, function(j) log(kappa(vcv(tree[[j]]),exact=TRUE)))  )
  
  
anova(lm((pgls.p[,2])~as.factor(ifelse(pgls.p[,1]<=0.05,0,1   ))))
tapply((pgls.p[,2]),as.factor(ifelse(pgls.p[,1]<=0.05,0,1)),mean)
tapply((pgls.p[,2]),as.factor(ifelse(pgls.p[,1]<=0.05,0,1)),var)

CNdata<-split(pgls.p,as.factor(ifelse(pgls.p[,1]<=0.05,0,1)))
hist(CNdata$'1', col=rgb(0,0,0,1),freq=FALSE)
hist(CNdata$'0', col=rgb(0.8,0.8,0.8,0.5), freq=FALSE,add=T)

write.csv(pgls.p,"PBTree-CN-Significance.csv")
