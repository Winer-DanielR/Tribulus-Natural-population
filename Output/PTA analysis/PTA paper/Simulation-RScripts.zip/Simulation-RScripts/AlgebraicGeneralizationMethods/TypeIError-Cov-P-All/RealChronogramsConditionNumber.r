# Evaluate condition number of actual chronograms. Compare to theoretical PB and RTree
####
library(ape)
sim.data<-read.csv("MeanCondValSims.csv")
load("opentree_chronograms.rda")
ntrees<-length(datelife.cache$trees)
ntaxa<-unlist(lapply(1:ntrees, function(x) length(datelife.cache$trees[[x]]$tip.label    )))

#Prune out large trees (N > 512) and those with negative branch lengths  
large<-which(ntaxa >512)
bad<-130 #contains poorly sampled outgroup taxa which biased analyses of original paper (see original paper)
good.branch<-array(NA,length(ntaxa))
for (j in 1:length(ntaxa)){ good.branch[j]<-any(datelife.cache$trees[[j]]$edge.length<0) }
totgp<-seq(1,length(ntaxa)); totgp<-totgp[-c(large,which(good.branch==TRUE),bad)]
trees<-datelife.cache$trees; trees<-trees[totgp] # 120 phylogenies
ntaxa2<-ntaxa[totgp]

cond.num<-unlist(lapply(1:length(totgp), function(x) kappa(vcv(trees[[x]]), exact=TRUE)))
real.trees<-cbind(ntaxa2,cond.num)

plot(real.trees[,1],real.trees[,2],pch=21,cex=1,bg="black",ylim=c(0,max(sim.data[,3])))
lines(sim.data[,2],sim.data[,3],col="black",lty=2,lwd=2)
lines(sim.data[,2],sim.data[,4],col="gray",lwd=2)

