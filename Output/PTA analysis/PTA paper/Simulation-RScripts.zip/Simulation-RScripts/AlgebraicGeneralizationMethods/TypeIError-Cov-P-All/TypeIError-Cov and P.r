#Demonstration that PCM algabraic generalizations of Adams are robust to trait covariance

####
library(geomorph)
library(geiger)
library(phytools)

#1: phylogenetic signal
Nspec<-32
p<-c(2,8,16,32)
R<-c(0,0.5,0.9)
iter<-1000
physig.p<-array(NA,dim=(c(iter,length(R),length(p))))
for (i in 1:length(R)){
  for (j in 1:length(p)){
    for (k in 1:iter){
      tree.null<-compute.brlen(stree(n=Nspec))
      #      tree<-pbtree(n=Nspec,scale=1) 
      tree<-compute.brlen(rtree(Nspec))
      s=matrix(R[i],ncol=p[j],nrow=p[j]); diag(s)<-1
      y<-sim.char(tree.null,s,1)[,,1] 
      physig.p[k,i,j] <-physignal(y,tree,print.progress = FALSE)$pvalue
      print(c(i,j,k))
    }
  }
}
res<-NULL
for (i in 1:length(p)){
  res<-rbind(res,apply(ifelse(physig.p[,,i]<=0.05,1,0),2,mean))
}
row.names(res)<-p
colnames(res)<-R
res
write.csv(res,"physig.typeI.csv")


#2: Rate comparisons
Nspec<-32
p<-c(2,8,16,32)
R<-c(0,0.5,0.9)
groups<-gl(2,16,labels=c("0","1")); names(groups)<-rownames(y)
iter<-1000
rate.p<-array(NA,dim=(c(iter,length(R),length(p))))
for (i in 1:length(R)){
  for (j in 1:length(p)){
    for (k in 1:iter){
      tree<-compute.brlen(rtree(Nspec))
      #      tree<-pbtree(n=Nspec,scale=1) 
      s=matrix(R[i],ncol=p[j],nrow=p[j]); diag(s)<-1
      y<-sim.char(tree,s,1)[,,1] 
      rate.p[k,i,j] <-compare.evol.rates(y,tree,gp=groups,print.progress = FALSE)$P.value
      print(c(i,j,k))
    }
  }
}
res<-NULL
for (i in 1:length(p)){
  res<-rbind(res,apply(ifelse(rate.p[,,i]<=0.05,1,0),2,mean))
}
row.names(res)<-p
colnames(res)<-R
res
write.csv(res,"rate.typeI.csv")


#3: PGLS
Nspec<-32
p<-c(2,8,16,32)
R<-c(0,0.5,0.9)
iter<-1000
pgls.p<-array(NA,dim=(c(iter,length(R),length(p))))
for (i in 1:length(R)){
  for (j in 1:length(p)){
    for (k in 1:iter){
      tree<-compute.brlen(rtree(Nspec))
      #      tree<-pbtree(n=Nspec,scale=1) 
      s=matrix(R[i],ncol=(p[j]+1),nrow=(p[j]+1)) 
      s[,(p[j]+1)]<-s[(p[j]+1),]<-0; diag(s)<-1
      dat<-sim.char(tree,s,1)[,,1]
      y<-dat[,1:p[j]]; x<-dat[,(p[j]+1)]
      pgls.p[k,i,j] <-procD.pgls(y~x,tree,print.progress = FALSE)$aov.table[1,7]
      print(c(i,j,k))
    }
  }
}
res<-NULL
for (i in 1:length(p)){
  res<-rbind(res,apply(ifelse(pgls.p[,,i]<=0.05,1,0),2,mean))
}
row.names(res)<-p
colnames(res)<-R
res
write.csv(res,"pgls.typeI.csv")


#4: PPLS
Nspec<-32
p<-c(2,8,16,32)
R<-c(0,0.5,0.9)
iter<-1000
ppls.p<-array(NA,dim=(c(iter,length(R),length(p))))
for (i in 1:length(R)){
  for (j in 1:length(p)){
    for (k in 1:iter){
      tree<-compute.brlen(rtree(Nspec))
      #      tree<-pbtree(n=Nspec,scale=1) 
      s=matrix(R[i],ncol=2*p[j],nrow=2*p[j]) 
      s[1:p[j],(p[j]+1):(2*p[j])]<-s[(p[j]+1):(2*p[j]),1:p[j]]<-0;diag(s)<-1
      x.in<-sim.char(tree,s,1)[,,1] 
      y<-x.in[,1:p[j]];x<-x.in[,-(1:p[j])]
      ppls.p[k,i,j] <-phylo.integration(y,x,tree,print.progress = FALSE)$P.value
      print(c(i,j,k))
    }   
  }
}
res<-NULL
for (i in 1:length(p)){
  res<-rbind(res,apply(ifelse(ppls.p[,,i]<=0.05,1,0),2,mean))
}
row.names(res)<-p
colnames(res)<-R
res
write.csv(res,"ppls.typeI.csv")

