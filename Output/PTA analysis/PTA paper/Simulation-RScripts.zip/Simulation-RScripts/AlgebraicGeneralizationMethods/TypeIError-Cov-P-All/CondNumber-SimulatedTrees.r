#Evaluate Condition Number for simulated trees

###
library(phytools)
library(ape)

Nspec<-c(8,16,32,64,128,256,512)
Nsimul<-500
kappa.pb<-kappa.rt<-array(NA,dim=c(Nsimul,length(Nspec)))
for (i in 1:length(Nspec)){
  trees.pb<-pbtree(n=Nspec[i],scale=1,nsim=Nsimul)
  kappa.pb[,i]<-unlist(lapply(1:100, function(x) kappa(vcv(trees.pb[[x]]),exact=TRUE)))
  
  trees.rt<-lapply(1:Nsimul, function(x) compute.brlen(rtree(Nspec[x]))  ) 
  kappa.rt[,i]<-unlist(lapply(1:100, function(x) kappa(vcv(trees.rt[[x]]),exact=TRUE)))  
  
}
write.csv(kappa.pb,"KappaPB.sim.csv")
write.csv(kappa.rt,"KappaRT.sim.csv")
  mean.pb<-apply(kappa.pb,2,mean)
  mean.rt<-apply(kappa.rt,2,mean)
write.csv(cbind(Nspec,mean.pb,mean.rt),"MeanCondValSims.csv")

#Estimate pattern in Log-Log Plots
lkappa.pb<-log(kappa.pb) 
 mean.pb<-apply(lkappa.pb,2,mean)
 mean.rt<-apply(log(kappa.rt),2,mean)
 sd.pb<-apply(lkappa.pb,2,sd)
 
 plot(log(Nspec),mean.pb,ylim=c(0,max(mean.pb)))  
 lines(log(Nspec),mean.pb)
 lines(log(Nspec),mean.rt)
  lines(log(Nspec),(mean.pb+1.645*sd.pb))
 
CI.90U<-(mean.pb+1.645*sd.pb)
CI.90L<-(mean.pb-1.645*sd.pb)
unlist(lapply(1:length(Nspec), function(x) length(which(lkappa.pb[,x]>CI.90U[x]))  )) 
unlist(lapply(1:length(Nspec), function(x) length(which(lkappa.pb[,x]<CI.90L[x]))  ))

