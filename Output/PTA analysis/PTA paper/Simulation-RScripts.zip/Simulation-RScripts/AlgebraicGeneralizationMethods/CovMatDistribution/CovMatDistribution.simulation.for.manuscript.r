library(geomorph)
library(vegan)
library(geiger)

eccent <- function(P){
  p <- prcomp(P)
  e <- p$sdev^2
  1-e[2]/e[1]
}

Dist <- function(C){
  d <-lapply(1:(length(C)-1), function(j){
    x <- C[[j]]
    y <- C[-(1:j)]
    sapply(1:length(y), function(jj){
      d <- Re(eigen(geomorph:::fast.solve(x)%*%y[[jj]])$values)
      d <- d[d>0]
      sqrt(sum(log(d)^2))
    })
  })
  d <- unlist(d)
  Dmat <- dist(matrix(0,perm, perm))
  for(i in 1:length(Dmat)) Dmat[[i]] <- d[i]
  as.matrix(Dmat)
}

s.cov <- function(x) crossprod(x)/NROW(x)

# should use covariance matrix of fitted values
# That way observed covariance matrix is the "effect"
# As a departure from centroid
# This is more akin to Mitt & Book method

ntraits <- 4
nspecs <- 100
phy <- rtree(nspecs)
sigma <-matrix(0, ntraits+1,ntraits+1)
diag(sigma) <- 1
Y <- as.matrix(sim.char(phy, par=sigma)[,,1])
x <- prcomp(Y)$x[,1] + rnorm(nspecs, 0, 0.3)
Xf <- model.matrix(~x)
Xr <- as.matrix(Xf[,1])

Pcor <- geomorph:::phylo.mat(Y, phy)$D.mat
# Pcor <- diag(1, nspecs) # use this for linear regression
fit <- procD.pgls(Y~x, phy=phy)
fit
par(mfcol=c(2,2))
plot(fit)
par(mfcol=c(1,1))

iter <- 999
perm <- iter+1

# RRPP 

Yhr <- lm.fit(Xr, Y)$fitted.values
Res <- Y - Yhr
ind <- geomorph:::perm.index(nspecs, iter, seed = NULL)
ResR <- lapply(1:perm, function(j) Res[ind[[j]],])
# Note, covariance matrices of null models
cov.check <- Map(function(r) s.cov(r), ResR)
cov.check[[1]]
cov.check[[2]]
cov.check[[3]] # covariance matrices the same
Yr <- Map(function(r) Yhr + r, ResR)
Br <- Map(function(y) lm.fit(Pcor%*%Xf, Pcor%*%y)$coefficients, Yr)
Yhr <- Map(function(b) Xf%*%b, Br)
covr <- Map(function(r) s.cov(r), Yhr)

# Note, traces of random covariance matrices for fitted values
# (The RRPP way!)
sum(diag(covr[[1]])) # observed
sum(diag(covr[[2]])) # rnd 2
sum(diag(covr[[3]])) # rnd 3
sum(diag(covr[[4]])) # rnd 4

# Remove observed (to be safe) and find mean covariance matrix
cov.null <- covr[2:perm]
cov.null.mean <- Reduce("+",cov.null)/iter

# Distances among covariance matrices
d.effect <- Dist(covr)
d.null <- d.effect[-1,] # remove first row
d.null <- d.null[,-1] # remove first column

# Wishart simulations
covW <- rWishart(perm, nspecs, cov.null.mean)/nspecs
covW <- lapply(1:perm, function(j) as.matrix(covW[,,j]))

# Wishart distances
d.W <- Dist(covW)

# PCoA and preliminary plots
par(mfrow=c(1,3))
PCoA.W <- cmdscale(d.W)
PCoA.null <- cmdscale(d.null)
PCoA.effect <- cmdscale(d.effect)
plot(PCoA.W, asp=1, xlab="p1", ylab="p2")
plot(PCoA.null, asp=1, xlab="p1", ylab="p2")
plot(PCoA.effect, asp=1, xlab="p1", ylab="p2")
points(PCoA.effect[1,1],PCoA.effect[1,2],
       pch=19,cex=1.5)
par(mfcol=c(1,1))

# For posterity
good.results <-list(
  Y=Y, x=x, phy=phy, Pcor=Pcor, PCoA.W=PCoA.W,
  PCoA.null=PCoA.null, PCoA.effect=PCoA.effect,
  fit <- procD.pgls(Y~x, phy=phy)
)

save(good.results, file = "good.results.Rdata")

# End example

#### Simulation (takes some time)
nsims <- 100
iter <- 499
perm <- iter + 1
Result <- matrix(0, 3, nsims)

for(ii in 1:nsims){
  Y <- as.matrix(sim.char(phy, par=sigma)[,,1])
  x <- prcomp(Y)$x[,1] + rnorm(nspecs, 0, 0.3)
  Xf <- model.matrix(~x)
  Xr <- as.matrix(Xf[,1])
  Pcor <- geomorph:::phylo.mat(Y, phy)$D.mat
  # Pcor <- diag(1, nspecs) # use this for linear regression
  Yhr <- lm.fit(Xr, Y)$fitted.values
  Res <- Y - Yhr
  ind <- geomorph:::perm.index(nspecs, iter, seed = NULL)
  ResR <- lapply(1:perm, function(j) Res[ind[[j]],])
  Yr <- Map(function(r) Yhr + r, ResR)
  Br <- Map(function(y) lm.fit(Pcor%*%Xf, Pcor%*%y)$coefficients, Yr)
  Yhr <- Map(function(b) Xf%*%b, Br)
  covr <- Map(function(r) s.cov(r), Yhr)
  cov.null <- covr[2:perm]
  cov.null.mean <- Reduce("+",cov.null)/iter
  d.effect <- Dist(covr)
  d.null <- d.effect[-1,]
  d.null <- d.null[,-1]
  covW <- rWishart(perm, nspecs, cov.null.mean)/nspecs
  covW <- lapply(1:perm, function(j) as.matrix(covW[,,j]))
  d.W <- Dist(covW)
  PCoA.W <- cmdscale(d.W)
  PCoA.null <- cmdscale(d.null)
  PCoA.effect <- cmdscale(d.effect)
  Result[,ii] <- c(eccent(PCoA.null),
                   eccent(PCoA.effect),
                   eccent(PCoA.W))
  cat(paste("sim",ii,"... "))
}
rownames(Result) <- c("RRPP.null", "RRPP.w.obs", "Wishart")
save(Result, file="500.perm.simulation.eccentricity.results.Rdata")


# Bring back example results and plot
load("good.results.Rdata")
PCoA.W <- good.results$PCoA.W
PCoA.null <- good.results$PCoA.null
PCoA.effect <- good.results$PCoA.effect

par(mfrow=c(2,2))
plot(PCoA.null,pch=21,cex=1,asp=1,bg="lightgray", 
     xlab = "PCoord 1", ylab = "PCoord 2", 
     xaxt="n", yaxt="n",main = "a: RRPP without observed")
plot(PCoA.effect,pch=21,cex=1,asp=1,bg="lightgray", 
     xlab = "PCoord 1", ylab = "PCoord 2", 
     xaxt="n", yaxt="n",main = "b: RRPP with observed")
points(PCoA.effect[1,1],PCoA.effect[1,2],pch=21,cex=2,bg="black")
plot(PCoA.W,pch=21,cex=1,asp=1,bg="lightgray", 
     xlab = "PCoord 1", ylab = "PCoord 2", 
     xaxt="n", yaxt="n", main = "c: Wishart")
group <-rep(c("RRPP without obs","RRPP with obs", "Wishart"), nsims)
boxplot(as.vector(Result) ~ group, ylab = "Eccentricity", main = "D: Eccentricity")
par(mfrow=c(1,1))

# Same plot but without the observed value distraction

par(mfrow=c(1,3))
par(mar=c(3,3,3,1))
plot(PCoA.effect,pch=21,cex=1,asp=1,bg="lightgray", 
     xlab = "PCoord 1", ylab = "PCoord 2", 
     xaxt="n", yaxt="n", main = "a: RRPP ")
plot(PCoA.W,pch=21,cex=1,asp=1,bg="lightgray", 
     xlab = "PCoord 1", ylab = "PCoord 2", 
     xaxt="n", yaxt="n", main = "b: Wishart")
group <-rep(c("RRPP", "Wishart"), nsims)
boxplot(as.vector(Result[-1,]) ~ group, ylab = "Eccentricity", main = "c: Eccentricity")
par(mfrow=c(1,1))
par(mar=c(5,4,4,2))
