#Compare PGLS for orientation

####
library(ape)
library(geiger)
library(phytools)
library(phylocurve)

R<- c(0,0.5,0.9)
p<-8
Nspec=32
iter<-100

PCL.1<-PCL.2<-array(NA,dim=(c(iter,length(R))))
for(i in 1:length(R)){
  s<-matrix(R[i],ncol=p,nrow=p)
  s<-rbind(s,rep(0.3,p));s<-cbind(s,rep(0.2,(p+1)));diag(s)<-1
  #tree<-lapply(1:iter, function(j) pbtree(n=Nspec,scale=1)) #PB tree
  tree<-lapply(1:iter, function(j) compute.brlen(rtree(Nspec))) #random splits tree
  dat.sim<-lapply(1:iter, function(j) sim.char(tree[[j]],s,iter)[,,1])
  y<-lapply(1:iter, function(j) dat.sim[[j]][,1:p])
  x<-lapply(1:iter, function(j) dat.sim[[j]][,p+1])

  null <- lapply(1:iter, function(j) evo.model(tree = tree[[j]],Y = y[[j]],method="Pairwise ML"))
  alt <- lapply(1:iter, function(j) evo.model(tree = tree[[j]],Y = y[[j]],
         fixed.effects=x[[j]],method="Pairwise ML"))
  PCL.1[,i]<-unlist(lapply(1:iter, function(j) compare.models(model1 = null[[j]],
         model2 = alt[[j]],nsim = 1000,plot = FALSE,estimate_power = FALSE)$Pval ))
  
  null2 <- lapply(1:iter, function(j) evo.model(tree = tree[[j]],Y = prcomp(y[[j]])$x,method="Pairwise ML"))
  alt2 <- lapply(1:iter, function(j) evo.model(tree = tree[[j]],Y = prcomp(y[[j]])$x,
         fixed.effects=x[[j]],method="Pairwise ML"))
  PCL.2[,i]<-unlist(lapply(1:iter, function(j) compare.models(model1 = null2[[j]],
         model2 = alt2[[j]],nsim = 1000,plot = FALSE,estimate_power = FALSE)$Pval ))
}


res<-ifelse(PCL.1<=0.05,1,0)
apply(res,2,mean)
res2<-ifelse(PCL.2<=0.05,1,0)
apply(res2,2,mean)

write.csv(PCL.1,"PGLS.out-OrigOrient.csv")
write.csv(PCL.2,"PGLS.out-PCAOrient.csv")
