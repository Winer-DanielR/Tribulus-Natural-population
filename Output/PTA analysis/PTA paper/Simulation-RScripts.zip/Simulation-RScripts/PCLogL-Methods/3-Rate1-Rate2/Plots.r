## Plots from simulations

PCL.logL<-read.csv("RateComparison.PCL.Res.csv",header=T,row.names=1)

R<-c(0,.5,.9)
res<-ifelse(PCL.logL<=0.05,1,0)
p<-apply(res,2,mean)
p<-matrix(p,ncol=3,byrow=T);colnames(p)<-R
barplot((1-p),beside=T,ylim=c(0,1),ylab="% Misspecification",xlab="Input Covariation")




