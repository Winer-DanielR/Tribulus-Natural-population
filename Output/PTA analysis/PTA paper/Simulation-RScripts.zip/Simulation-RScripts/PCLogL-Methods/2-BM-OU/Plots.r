## Plots from simulations

PCL.logL<-read.csv("BM-OU.out-OrigOrient.csv",header=T,row.names=1)
PCL2.logL<-read.csv("BM-OU.out-PCAOrient.csv",header=T,row.names=1)

R<-c(0,.5,.9)
res<-ifelse(PCL.logL<=0.05,1,0)
res2<-ifelse(PCL2.logL<=0.05,1,0)
p.1<-apply(res,2,mean); names(p.1)=R
p.2<-apply(res2,2,mean); names(p.2)=R
p<-rbind(p.1,p.2)

barplot(p,beside=T,ylim=c(0,1),
        xlab="Input Covariation",ylab="% Misspecification")




