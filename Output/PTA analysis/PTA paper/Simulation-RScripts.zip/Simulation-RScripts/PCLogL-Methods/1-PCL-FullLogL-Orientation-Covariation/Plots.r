## Plots from simulations

#1&2: simulation 1: trait covaritaion and orientation
std.logL<- read.csv("Test1.std.logL.orient.csv",header=T,row.names=1)
std2.logL<-read.csv("Test1.std.logL.PCAorient.csv",header=T,row.names=1)
PCL.logL<-read.csv("Test1.PCL.logL.orient.csv",header=T,row.names=1)
PCL2.logL<-read.csv("Test1.PCL.logL.PCAorient.csv",header=T,row.names=1)
PCL3.logL<-read.csv("Test1.PCL.logL.PCAorientArb.csv",header=T,row.names=1)

R<-c(0,.3,.6,.9)
plot(R,diag(cor(std.logL,std2.logL)),ylim=c(0,1),pch=21,cex=1.5,bg="black")
 abline(1,0,col="gray",lwd=2)
 lines(R,diag(cor(std.logL,std2.logL)))

plot(R,diag(cor(std.logL,PCL.logL)),ylim=c(0,1),pch=21,cex=1.5,bg="black")
abline(1,0,col="gray",lwd=2)
 lines(R,diag(cor(std.logL,PCL.logL)))
 
plot(R,diag(cor(PCL.logL,PCL2.logL)),ylim=c(0,1),pch=21,cex=1.5,bg="black")
  abline(1,0,col="gray",lwd=2)
  abline(lm(diag(cor(PCL.logL,PCL2.logL))~R))

diag(cor(std.logL,PCL.logL))
diag(cor(std.logL,PCL2.logL))
diag(cor(std.logL,PCL3.logL))

diag(cor(PCL.logL,PCL3.logL))  
diag(cor(PCL.logL,PCL3.logL))  

#3: Effect of trait dimensionality on PCL 
p<-c(6,8,10,12,14,16,18,20,22,24,26,28,30,32) 
PCL.logL<-read.csv("Test2.PCL.logL.DataDimension.csv",header=T,row.names=1)
PCL2.logL<-read.csv("Test2.PCL.logL.PCADataDimension.csv",header=T,row.names=1)
PCL3.logL<-read.csv("Test2.PCL.logL.ArbRotDataDimension.csv",header=T,row.names=1)

plot(p,diag(cor(PCL.logL,PCL2.logL)),ylim=c(0,1),pch=21,cex=1.5,bg="black")
abline(1,0,col="gray",lwd=2)
abline(lm(diag(cor(PCL.logL,PCL2.logL))~p))

diag(cor(PCL.logL,PCL3.logL))
