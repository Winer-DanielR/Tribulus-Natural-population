#Demonstration of trait covariation and dataspace orientation dependence of PCL
  #PATTERNS consistent regardless of RT or PB trees as input
    #Patterns also consistent with eigen-rotations and arbitrary rotations

####
library(geiger)
library(phytools)
library(phylocurve)
library(geomorph)

#Revell & Harmon 2008 logL for multivariate data
StandardLogL<-function(phy,x){
  x<-as.matrix(x)
  N<-nrow(x)
  p<-ncol(x)
  C<-vcv.phylo(phy)
  C<-C[rownames(x),rownames(x)]
  a<-colSums(solve(C))%*%x/sum(solve(C))   
  D<-matrix(0,N*p,p)
  for(i in 1:(N*p)) for(j in 1:p) if((j-1)*N<i&&i<=j*N) D[i,j]=1.0
  y<-as.matrix(as.vector(x))
  one<-matrix(1,N,1)
  R<-t(x-one%*%a)%*%solve(C)%*%(x-one%*%a)/N
  L1<- -(t(y-D%*%t(a))%*%solve(kronecker(R,C))%*%(y-D%*%t(a))/2)-N*p*log(2*pi)/2-determinant(kronecker
                                                                                             (R,C))$modulus[1]/2
  return(list(LogL=L1,sigma=R))
}

#1&2: Full logL vs. PCL with increasing trait covariation and dataspace orientation
R<-c(0,.3,.6,.9)
p<-8
Nspec=32
iter=100
PCL.logL<-PCL2.logL<-PCL3.logL<-std.logL<-std2.logL<-std3.logL<-array(NA,dim=(c(iter,length(R))))
for (i in 1:length(R)){
  #tree<-lapply(1:iter, function(j) pbtree(n=Nspec,scale=1)) #PB tree
  tree<-lapply(1:iter, function(j) compute.brlen(rtree(Nspec))) #random splits tree
  s=matrix(R[i],ncol=p,nrow=p); diag(s)<-1
  y<-lapply(1:iter, function(j) sim.char(tree[[j]],s,iter)[,,1])
    RotMat<-lapply(1:iter, function(j) qr.Q(qr(array(runif(p), dim=c(p,p)))) )
  y.rot<-lapply(1:iter, function(j) y[[j]]%*%RotMat[[j]]) #arbitrary rotations    
  std.logL[,i] <-unlist(lapply(1:iter, function(j) StandardLogL(tree[[j]],y[[j]])$LogL ))
  std2.logL[,i] <-unlist(lapply(1:iter, function(j) StandardLogL(tree[[j]],prcomp(y[[j]])$x )$LogL ))
  std3.logL[,i] <-unlist(lapply(1:iter, function(j) StandardLogL(tree[[j]],y.rot[[j]])$LogL ))
  PCL.logL[,i] <-unlist(lapply(1:iter, function(j) evo.model(tree = tree[[j]],Y = y[[j]],method="Pairwise ML")$logL ))
  PCL2.logL[,i] <-unlist(lapply(1:iter, function(j) evo.model(tree = tree[[j]],Y = prcomp(y[[j]])$x,method="Pairwise ML")$logL ))
  PCL3.logL[,i] <-unlist(lapply(1:iter, function(j) evo.model(tree = tree[[j]],Y = y.rot[[j]],method="Pairwise ML")$logL ))
}
diag(cor(std.logL,PCL.logL))  
diag(cor(std.logL,std2.logL))
diag(cor(std.logL,std3.logL)) 
diag(cor(PCL.logL,PCL2.logL)) 
diag(cor(PCL.logL,PCL3.logL)) 

write.csv(std.logL,"Test1.std.logL.orient.csv")
write.csv(std2.logL,"Test1.std.logL.PCAorient.csv")
write.csv(std3.logL,"Test1.std.logL.PCAorientArb.csv")
write.csv(PCL.logL,"Test1.PCL.logL.orient.csv")
write.csv(PCL2.logL,"Test1.PCL.logL.PCAorient.csv")
write.csv(PCL3.logL,"Test1.PCL.logL.PCAorientArb.csv")

#3: Effect of trait dimensionality on PCL 
R<-c(.7)
p<-c(6,8,10,12,14,16,18,20,22,24,26,28,30,32) #p<-c(4,8,16,32)
Nspec=32
iter=100
PCL.logL<-PCL2.logL<-PCL3.logL<-array(NA,dim=(c(iter,length(p))))
for (i in 1:length(p)){
  #tree<-lapply(1:iter, function(j) pbtree(n=Nspec,scale=1)) #PB tree
  tree<-lapply(1:iter, function(j) compute.brlen(rtree(Nspec))) #random splits tree
  s=matrix(R,ncol=p[i],nrow=p[i]); diag(s)<-1
  y<-lapply(1:iter, function(j) sim.char(tree[[j]],s,iter)[,,1])
  RotMat<-lapply(1:iter, function(j) qr.Q(qr(array(runif(p[i]), dim=c(p[i],p[i])))) )
  y.rot<-lapply(1:iter, function(j) y[[j]]%*%RotMat[[j]]) #arbitrary rotations    
  PCL.logL[,i] <-unlist(lapply(1:iter, function(j) evo.model(tree = tree[[j]],Y = y[[j]],method="Pairwise ML")$logL ))
  PCL2.logL[,i] <-unlist(lapply(1:iter, function(j) evo.model(tree = tree[[j]],Y = prcomp(y[[j]])$x,method="Pairwise ML")$logL ))
  PCL3.logL[,i] <-unlist(lapply(1:iter, function(j) evo.model(tree = tree[[j]],Y = y.rot[[j]],method="Pairwise ML")$logL ))
}
diag(cor(PCL.logL,PCL2.logL)) 
range(diag(cor(PCL.logL,PCL2.logL)) )
plot(p,diag(cor(PCL.logL,PCL2.logL)) )
diag(cor(PCL.logL,PCL3.logL)) 

write.csv(PCL.logL,"Test2.PCL.logL.DataDimension.csv")
write.csv(PCL2.logL,"Test2.PCL.logL.PCADataDimension.csv")
write.csv(PCL3.logL,"Test2.PCL.logL.ArbRotDataDimension.csv")
