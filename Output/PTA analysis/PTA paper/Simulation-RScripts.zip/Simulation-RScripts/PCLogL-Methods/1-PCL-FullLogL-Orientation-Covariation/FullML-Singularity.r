#Demonstration that multivariate logL is not computable for GM shape data

####
library(geomorph)

#Revell & Harmon 2008 logL for multivariate data
StandardLogL<-function(phy,x){
  x<-as.matrix(x)
  N<-nrow(x)
  p<-ncol(x)
  C<-vcv.phylo(phy)
  C<-C[rownames(x),rownames(x)]
  a<-colSums(solve(C))%*%x/sum(solve(C))   
  D<-matrix(0,N*p,p)
  for(i in 1:(N*p)) for(j in 1:p) if((j-1)*N<i&&i<=j*N) D[i,j]=1.0
  y<-as.matrix(as.vector(x))
  one<-matrix(1,N,1)
  R<-t(x-one%*%a)%*%solve(C)%*%(x-one%*%a)/N
  L1<- -(t(y-D%*%t(a))%*%solve(kronecker(R,C))%*%(y-D%*%t(a))/2)-N*p*log(2*pi)/2-determinant(kronecker
                                                                                             (R,C))$modulus[1]/2
  return(list(LogL=L1,sigma=R))
}

data("plethspecies")
Y.gpa<-gpagen(plethspecies$land[1:3,,])  #use only 3 landmarks, so RXC otherwise computable
x<-two.d.array(Y.gpa$coords)
phy<-plethspecies$phy

StandardLogL(phy,x)

#Why this fails: R is singular
x<-as.matrix(x)
N<-nrow(x)
p<-ncol(x)
C<-vcv.phylo(phy)
C<-C[rownames(x),rownames(x)]
a<-colSums(solve(C))%*%x/sum(solve(C))   
D<-matrix(0,N*p,p)
for(i in 1:(N*p)) for(j in 1:p) if((j-1)*N<i&&i<=j*N) D[i,j]=1.0
y<-as.matrix(as.vector(x))
one<-matrix(1,N,1)
R<-t(x-one%*%a)%*%solve(C)%*%(x-one%*%a)/N

solve(R)
