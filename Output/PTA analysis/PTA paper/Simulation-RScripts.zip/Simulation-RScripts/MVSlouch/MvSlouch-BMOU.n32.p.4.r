#Degree of misspecification from mvSlouch
####
library(geiger)
library(phytools)
library(mvSLOUCH)

R<-c(0)
p<-4
Nspec=32
iter=100
BM.p<-OU.aic<-BM.aic<-array(NA,dim=(c(iter)))
for (j in 1:iter){
    tree<-compute.brlen(rtree(Nspec))  #random splits tree
    s=matrix(R,ncol=p,nrow=p); diag(s)<-1
    y<-sim.char(tree,s,1)[,,1] 
    tree<-ape2ouch(tree)
    BM1.res<-BrownianMotionModel(tree,y)
    OU.res<-ouchModel(tree,y)
    OU.aic[j]<-OU.res$FinalFound$ParamSummary$aic
    BM.aic[j]<-BM1.res$ParamSummary$aic
    BM.p[j]<-OU.res$FinalFound$ParamSummary$aic-BM1.res$ParamSummary$aic #compare AIC
    print(j)
  }


#AIC comparison @ 4+
length(which(BM.p< -4))

write.csv(cbind(BM.p,OU.aic,BM.aic),"BMOU.32.4.out.csv")
